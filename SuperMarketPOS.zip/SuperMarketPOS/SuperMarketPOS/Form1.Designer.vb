﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstGrcryList = New System.Windows.Forms.ListBox()
        Me.btnBrownSugar = New System.Windows.Forms.Button()
        Me.btnCereal = New System.Windows.Forms.Button()
        Me.btnBanana = New System.Windows.Forms.Button()
        Me.btnAlmoundMlk = New System.Windows.Forms.Button()
        Me.btnCanMilk = New System.Windows.Forms.Button()
        Me.btnBrownRice = New System.Windows.Forms.Button()
        Me.btnGum = New System.Windows.Forms.Button()
        Me.btnTurkeyBac = New System.Windows.Forms.Button()
        Me.btnEggs = New System.Windows.Forms.Button()
        Me.btnButter = New System.Windows.Forms.Button()
        Me.btnOrangeJuice = New System.Windows.Forms.Button()
        Me.btnHWBread = New System.Windows.Forms.Button()
        Me.btnRmSelected = New System.Windows.Forms.Button()
        Me.lblSubTotal = New System.Windows.Forms.Label()
        Me.lblFinTotal = New System.Windows.Forms.Label()
        Me.lblTaxes = New System.Windows.Forms.Label()
        Me.btnCountItem = New System.Windows.Forms.Button()
        Me.btnClearLst = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnAddTotal = New System.Windows.Forms.Button()
        Me.lblNumItem = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstGrcryList
        '
        Me.lstGrcryList.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstGrcryList.FormattingEnabled = True
        Me.lstGrcryList.ItemHeight = 24
        Me.lstGrcryList.Location = New System.Drawing.Point(12, 26)
        Me.lstGrcryList.Name = "lstGrcryList"
        Me.lstGrcryList.Size = New System.Drawing.Size(318, 340)
        Me.lstGrcryList.TabIndex = 0
        '
        'btnBrownSugar
        '
        Me.btnBrownSugar.BackColor = System.Drawing.Color.Linen
        Me.btnBrownSugar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBrownSugar.ForeColor = System.Drawing.Color.DeepPink
        Me.btnBrownSugar.Location = New System.Drawing.Point(354, 105)
        Me.btnBrownSugar.Name = "btnBrownSugar"
        Me.btnBrownSugar.Size = New System.Drawing.Size(119, 67)
        Me.btnBrownSugar.TabIndex = 2
        Me.btnBrownSugar.Text = "BROWN SUGAR"
        Me.btnBrownSugar.UseVisualStyleBackColor = False
        '
        'btnCereal
        '
        Me.btnCereal.BackColor = System.Drawing.Color.Linen
        Me.btnCereal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCereal.ForeColor = System.Drawing.Color.DeepPink
        Me.btnCereal.Location = New System.Drawing.Point(354, 185)
        Me.btnCereal.Name = "btnCereal"
        Me.btnCereal.Size = New System.Drawing.Size(119, 67)
        Me.btnCereal.TabIndex = 3
        Me.btnCereal.Text = "CEREAL"
        Me.btnCereal.UseVisualStyleBackColor = False
        '
        'btnBanana
        '
        Me.btnBanana.BackColor = System.Drawing.Color.Linen
        Me.btnBanana.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBanana.ForeColor = System.Drawing.Color.DeepPink
        Me.btnBanana.Location = New System.Drawing.Point(354, 259)
        Me.btnBanana.Name = "btnBanana"
        Me.btnBanana.Size = New System.Drawing.Size(119, 67)
        Me.btnBanana.TabIndex = 6
        Me.btnBanana.Text = "BANANA"
        Me.btnBanana.UseVisualStyleBackColor = False
        '
        'btnAlmoundMlk
        '
        Me.btnAlmoundMlk.BackColor = System.Drawing.Color.Linen
        Me.btnAlmoundMlk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAlmoundMlk.ForeColor = System.Drawing.Color.DeepPink
        Me.btnAlmoundMlk.Location = New System.Drawing.Point(479, 105)
        Me.btnAlmoundMlk.Name = "btnAlmoundMlk"
        Me.btnAlmoundMlk.Size = New System.Drawing.Size(119, 67)
        Me.btnAlmoundMlk.TabIndex = 5
        Me.btnAlmoundMlk.Text = "ALMOUND MILK"
        Me.btnAlmoundMlk.UseVisualStyleBackColor = False
        '
        'btnCanMilk
        '
        Me.btnCanMilk.BackColor = System.Drawing.Color.Linen
        Me.btnCanMilk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCanMilk.ForeColor = System.Drawing.Color.DeepPink
        Me.btnCanMilk.Location = New System.Drawing.Point(479, 29)
        Me.btnCanMilk.Name = "btnCanMilk"
        Me.btnCanMilk.Size = New System.Drawing.Size(119, 67)
        Me.btnCanMilk.TabIndex = 4
        Me.btnCanMilk.Text = "CAN MILK"
        Me.btnCanMilk.UseVisualStyleBackColor = False
        '
        'btnBrownRice
        '
        Me.btnBrownRice.BackColor = System.Drawing.Color.Linen
        Me.btnBrownRice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBrownRice.ForeColor = System.Drawing.Color.DeepPink
        Me.btnBrownRice.Location = New System.Drawing.Point(479, 185)
        Me.btnBrownRice.Name = "btnBrownRice"
        Me.btnBrownRice.Size = New System.Drawing.Size(119, 67)
        Me.btnBrownRice.TabIndex = 9
        Me.btnBrownRice.Text = "BROWN RICE"
        Me.btnBrownRice.UseVisualStyleBackColor = False
        '
        'btnGum
        '
        Me.btnGum.BackColor = System.Drawing.Color.Linen
        Me.btnGum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGum.ForeColor = System.Drawing.Color.DeepPink
        Me.btnGum.Location = New System.Drawing.Point(354, 29)
        Me.btnGum.Name = "btnGum"
        Me.btnGum.Size = New System.Drawing.Size(119, 67)
        Me.btnGum.TabIndex = 8
        Me.btnGum.Text = "GUM"
        Me.btnGum.UseVisualStyleBackColor = False
        '
        'btnTurkeyBac
        '
        Me.btnTurkeyBac.BackColor = System.Drawing.Color.Linen
        Me.btnTurkeyBac.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTurkeyBac.ForeColor = System.Drawing.Color.DeepPink
        Me.btnTurkeyBac.Location = New System.Drawing.Point(605, 185)
        Me.btnTurkeyBac.Name = "btnTurkeyBac"
        Me.btnTurkeyBac.Size = New System.Drawing.Size(119, 67)
        Me.btnTurkeyBac.TabIndex = 12
        Me.btnTurkeyBac.Text = "TURKEY BACON"
        Me.btnTurkeyBac.UseVisualStyleBackColor = False
        '
        'btnEggs
        '
        Me.btnEggs.BackColor = System.Drawing.Color.Linen
        Me.btnEggs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEggs.ForeColor = System.Drawing.Color.DeepPink
        Me.btnEggs.Location = New System.Drawing.Point(605, 105)
        Me.btnEggs.Name = "btnEggs"
        Me.btnEggs.Size = New System.Drawing.Size(119, 67)
        Me.btnEggs.TabIndex = 11
        Me.btnEggs.Text = "EGGS"
        Me.btnEggs.UseVisualStyleBackColor = False
        '
        'btnButter
        '
        Me.btnButter.BackColor = System.Drawing.Color.Linen
        Me.btnButter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnButter.ForeColor = System.Drawing.Color.DeepPink
        Me.btnButter.Location = New System.Drawing.Point(605, 29)
        Me.btnButter.Name = "btnButter"
        Me.btnButter.Size = New System.Drawing.Size(119, 67)
        Me.btnButter.TabIndex = 10
        Me.btnButter.Text = "BUTTER"
        Me.btnButter.UseVisualStyleBackColor = False
        '
        'btnOrangeJuice
        '
        Me.btnOrangeJuice.BackColor = System.Drawing.Color.Linen
        Me.btnOrangeJuice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrangeJuice.ForeColor = System.Drawing.Color.DeepPink
        Me.btnOrangeJuice.Location = New System.Drawing.Point(605, 259)
        Me.btnOrangeJuice.Name = "btnOrangeJuice"
        Me.btnOrangeJuice.Size = New System.Drawing.Size(119, 67)
        Me.btnOrangeJuice.TabIndex = 14
        Me.btnOrangeJuice.Text = "ORANGE JUICE"
        Me.btnOrangeJuice.UseVisualStyleBackColor = False
        '
        'btnHWBread
        '
        Me.btnHWBread.BackColor = System.Drawing.Color.Linen
        Me.btnHWBread.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHWBread.ForeColor = System.Drawing.Color.DeepPink
        Me.btnHWBread.Location = New System.Drawing.Point(479, 259)
        Me.btnHWBread.Name = "btnHWBread"
        Me.btnHWBread.Size = New System.Drawing.Size(119, 67)
        Me.btnHWBread.TabIndex = 15
        Me.btnHWBread.Text = "WHOLE WHEAT BREAD"
        Me.btnHWBread.UseVisualStyleBackColor = False
        '
        'btnRmSelected
        '
        Me.btnRmSelected.BackColor = System.Drawing.Color.Aqua
        Me.btnRmSelected.ForeColor = System.Drawing.Color.DarkOrchid
        Me.btnRmSelected.Location = New System.Drawing.Point(533, 406)
        Me.btnRmSelected.Name = "btnRmSelected"
        Me.btnRmSelected.Size = New System.Drawing.Size(111, 58)
        Me.btnRmSelected.TabIndex = 17
        Me.btnRmSelected.Text = "REMOVE SELECTED ITEM"
        Me.btnRmSelected.UseVisualStyleBackColor = False
        '
        'lblSubTotal
        '
        Me.lblSubTotal.BackColor = System.Drawing.SystemColors.InfoText
        Me.lblSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSubTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubTotal.ForeColor = System.Drawing.Color.LawnGreen
        Me.lblSubTotal.Location = New System.Drawing.Point(283, 377)
        Me.lblSubTotal.Name = "lblSubTotal"
        Me.lblSubTotal.Size = New System.Drawing.Size(108, 44)
        Me.lblSubTotal.TabIndex = 18
        '
        'lblFinTotal
        '
        Me.lblFinTotal.BackColor = System.Drawing.SystemColors.InfoText
        Me.lblFinTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFinTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinTotal.ForeColor = System.Drawing.Color.LawnGreen
        Me.lblFinTotal.Location = New System.Drawing.Point(283, 479)
        Me.lblFinTotal.Name = "lblFinTotal"
        Me.lblFinTotal.Size = New System.Drawing.Size(108, 44)
        Me.lblFinTotal.TabIndex = 19
        '
        'lblTaxes
        '
        Me.lblTaxes.BackColor = System.Drawing.SystemColors.InfoText
        Me.lblTaxes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTaxes.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTaxes.ForeColor = System.Drawing.Color.LawnGreen
        Me.lblTaxes.Location = New System.Drawing.Point(283, 432)
        Me.lblTaxes.Name = "lblTaxes"
        Me.lblTaxes.Size = New System.Drawing.Size(108, 44)
        Me.lblTaxes.TabIndex = 20
        '
        'btnCountItem
        '
        Me.btnCountItem.BackColor = System.Drawing.Color.CornflowerBlue
        Me.btnCountItem.ForeColor = System.Drawing.Color.Cornsilk
        Me.btnCountItem.Location = New System.Drawing.Point(533, 470)
        Me.btnCountItem.Name = "btnCountItem"
        Me.btnCountItem.Size = New System.Drawing.Size(111, 58)
        Me.btnCountItem.TabIndex = 22
        Me.btnCountItem.Text = "COUNT ITEMS"
        Me.btnCountItem.UseVisualStyleBackColor = False
        '
        'btnClearLst
        '
        Me.btnClearLst.BackColor = System.Drawing.Color.DarkKhaki
        Me.btnClearLst.ForeColor = System.Drawing.Color.Cornsilk
        Me.btnClearLst.Location = New System.Drawing.Point(408, 469)
        Me.btnClearLst.Name = "btnClearLst"
        Me.btnClearLst.Size = New System.Drawing.Size(111, 58)
        Me.btnClearLst.TabIndex = 23
        Me.btnClearLst.Text = "CLEAR ITEMS"
        Me.btnClearLst.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Red
        Me.btnExit.ForeColor = System.Drawing.Color.Cyan
        Me.btnExit.Location = New System.Drawing.Point(659, 406)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(111, 121)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "SHUTDOWN POS"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnAddTotal
        '
        Me.btnAddTotal.BackColor = System.Drawing.Color.DarkOrange
        Me.btnAddTotal.ForeColor = System.Drawing.Color.Cyan
        Me.btnAddTotal.Location = New System.Drawing.Point(408, 405)
        Me.btnAddTotal.Name = "btnAddTotal"
        Me.btnAddTotal.Size = New System.Drawing.Size(111, 58)
        Me.btnAddTotal.TabIndex = 25
        Me.btnAddTotal.Text = "ADD TOTAL"
        Me.btnAddTotal.UseVisualStyleBackColor = False
        '
        'lblNumItem
        '
        Me.lblNumItem.BackColor = System.Drawing.SystemColors.InfoText
        Me.lblNumItem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNumItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumItem.ForeColor = System.Drawing.Color.LawnGreen
        Me.lblNumItem.Location = New System.Drawing.Point(283, 525)
        Me.lblNumItem.Name = "lblNumItem"
        Me.lblNumItem.Size = New System.Drawing.Size(108, 36)
        Me.lblNumItem.TabIndex = 26
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label1.Location = New System.Drawing.Point(8, 397)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(244, 24)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "CUSTOMER SUBTOTAL:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label2.Location = New System.Drawing.Point(12, 452)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(206, 24)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "CUSTOMER TAXES:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label3.Location = New System.Drawing.Point(8, 498)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(268, 24)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "CUSTOMER FINAL TOTAL:"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label4.Location = New System.Drawing.Point(9, 536)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(243, 21)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "# OF ITEMS IN CART:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(782, 566)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblNumItem)
        Me.Controls.Add(Me.btnAddTotal)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClearLst)
        Me.Controls.Add(Me.btnCountItem)
        Me.Controls.Add(Me.lblTaxes)
        Me.Controls.Add(Me.lblFinTotal)
        Me.Controls.Add(Me.lblSubTotal)
        Me.Controls.Add(Me.btnRmSelected)
        Me.Controls.Add(Me.btnHWBread)
        Me.Controls.Add(Me.btnOrangeJuice)
        Me.Controls.Add(Me.btnTurkeyBac)
        Me.Controls.Add(Me.btnEggs)
        Me.Controls.Add(Me.btnButter)
        Me.Controls.Add(Me.btnBrownRice)
        Me.Controls.Add(Me.btnGum)
        Me.Controls.Add(Me.btnBanana)
        Me.Controls.Add(Me.btnAlmoundMlk)
        Me.Controls.Add(Me.btnCanMilk)
        Me.Controls.Add(Me.btnCereal)
        Me.Controls.Add(Me.btnBrownSugar)
        Me.Controls.Add(Me.lstGrcryList)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstGrcryList As ListBox
    Friend WithEvents btnBrownSugar As Button
    Friend WithEvents btnCereal As Button
    Friend WithEvents btnBanana As Button
    Friend WithEvents btnAlmoundMlk As Button
    Friend WithEvents btnCanMilk As Button
    Friend WithEvents btnBrownRice As Button
    Friend WithEvents btnGum As Button
    Friend WithEvents btnTurkeyBac As Button
    Friend WithEvents btnEggs As Button
    Friend WithEvents btnButter As Button
    Friend WithEvents btnOrangeJuice As Button
    Friend WithEvents btnHWBread As Button
    Friend WithEvents btnRmSelected As Button
    Friend WithEvents lblSubTotal As Label
    Friend WithEvents lblFinTotal As Label
    Friend WithEvents lblTaxes As Label
    Friend WithEvents btnCountItem As Button
    Friend WithEvents btnClearLst As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnAddTotal As Button
    Friend WithEvents lblNumItem As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
End Class
