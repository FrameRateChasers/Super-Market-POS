﻿Public Class Form1

    Const NYS_TAX = 2.0
    Const BROWN_SUG As Double = 2.69
    Const W_CEREARL As Double = 5.99
    Const BANANA As Double = 1.5
    Const ORAN_JUICE As Double = 3.99
    Const CAN_MLK As Double = 4.99
    Const ALMD_MLK As Double = 7.99
    Const CHEW_GUM As Double = 0.99
    Const BRWN_RICE As Double = 13.99
    Const BUTT_ER As Double = 5.99
    Const BRWN_EGGS As Double = 9.99
    Const WHOLE_WEAT_BREAD As Double = 5.99
    Const TUR_BAC As Double = 2.99
    Dim dblTaxTotal As Double
    Dim dblSubTotal As Double
    Dim dblFinTotal As Double
    Dim dblGroceryListItems As Double
    Dim strGrName() As String = {"Brown Sugar", "Cereal", "Banana", "Oragne Juice", "Can Milk", "Almound Milk", "Gum", "Brown Rice", "Butter", "Eggs", "Whole Wheat Bread", "Turkey Bacon"}

    Private Sub btnHWBread_Click(sender As Object, e As EventArgs) Handles btnHWBread.Click
        lstGrcryList.Items.Add(strGrName(10))
        dblGroceryListItems += WHOLE_WEAT_BREAD
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnOrangeJuice_Click(sender As Object, e As EventArgs) Handles btnOrangeJuice.Click
        lstGrcryList.Items.Add(strGrName(3))
        dblGroceryListItems += ORAN_JUICE
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnTurkeyBac_Click(sender As Object, e As EventArgs) Handles btnTurkeyBac.Click
        lstGrcryList.Items.Add(strGrName(11))
        dblGroceryListItems += TUR_BAC
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnEggs_Click(sender As Object, e As EventArgs) Handles btnEggs.Click
        lstGrcryList.Items.Add(strGrName(9))
        dblGroceryListItems += BRWN_EGGS
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnButter_Click(sender As Object, e As EventArgs) Handles btnButter.Click
        lstGrcryList.Items.Add(strGrName(8))
        dblGroceryListItems += BUTT_ER
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnBrownRice_Click(sender As Object, e As EventArgs) Handles btnBrownRice.Click
        lstGrcryList.Items.Add(strGrName(7))
        dblGroceryListItems += BRWN_RICE
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnGum_Click(sender As Object, e As EventArgs) Handles btnGum.Click
        lstGrcryList.Items.Add(strGrName(6))
        dblGroceryListItems += CHEW_GUM
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnBanana_Click(sender As Object, e As EventArgs) Handles btnBanana.Click
        lstGrcryList.Items.Add(strGrName(2))
        dblGroceryListItems += BANANA
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnAlmoundMlk_Click(sender As Object, e As EventArgs) Handles btnAlmoundMlk.Click
        lstGrcryList.Items.Add(strGrName(5))
        dblGroceryListItems += ALMD_MLK
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnCanMilk_Click(sender As Object, e As EventArgs) Handles btnCanMilk.Click
        lstGrcryList.Items.Add(strGrName(4))
        dblGroceryListItems += CAN_MLK
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnCereal_Click(sender As Object, e As EventArgs) Handles btnCereal.Click
        lstGrcryList.Items.Add(strGrName(1))
        dblGroceryListItems += W_CEREARL
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnBrownSugar_Click(sender As Object, e As EventArgs) Handles btnBrownSugar.Click
        lstGrcryList.Items.Add(strGrName(0))
        dblGroceryListItems += BROWN_SUG
        lblNumItem.Text = lstGrcryList.Items.Count

    End Sub

    Private Sub btnAddTotal_Click(sender As Object, e As EventArgs) Handles btnAddTotal.Click
        If lstGrcryList.Items.Count = 0 Then
            MsgBox("Please add items to cart", MsgBoxStyle.Critical)
            lstGrcryList.Items.Clear()
            lblSubTotal.Text = ""
            lblTaxes.Text = ""
            lblFinTotal.Text = ""
            lblNumItem.Text = ""

            dblGroceryListItems = 0.0

        Else
            dblSubTotal = dblGroceryListItems
            dblTaxTotal = dblGroceryListItems * (NYS_TAX / 100)
            dblFinTotal = dblSubTotal + dblTaxTotal

            lblSubTotal.Text = dblSubTotal.ToString("c")
            lblTaxes.Text = dblTaxTotal.ToString("c")
            lblFinTotal.Text = dblFinTotal.ToString("c")

            lblNumItem.Text = lstGrcryList.Items.Count

        End If
    End Sub

    Private Sub btnRmSelected_Click(sender As Object, e As EventArgs) Handles btnRmSelected.Click
        If lstGrcryList.SelectedIndex = -1 Then
            MsgBox("Please select an item you want to be deleted", MsgBoxStyle.Critical)
        Else
            Select Case lstGrcryList.SelectedItem
                Case = strGrName(0)
                    dblGroceryListItems -= BROWN_SUG
                Case = strGrName(1)
                    dblGroceryListItems -= W_CEREARL
                Case = strGrName(2)
                    dblGroceryListItems -= BANANA
                Case = strGrName(3)
                    dblGroceryListItems -= ORAN_JUICE
                Case = strGrName(4)
                    dblGroceryListItems -= CAN_MLK
                Case = strGrName(5)
                    dblGroceryListItems -= ALMD_MLK
                Case = strGrName(6)
                    dblGroceryListItems -= CHEW_GUM
                Case = strGrName(7)
                    dblGroceryListItems -= BRWN_RICE
                Case = strGrName(8)
                    dblGroceryListItems -= BUTT_ER
                Case = strGrName(9)
                    dblGroceryListItems -= BRWN_EGGS
                Case = strGrName(10)
                    dblGroceryListItems -= WHOLE_WEAT_BREAD
                Case = strGrName(11)
                    dblGroceryListItems -= TUR_BAC
            End Select

            lstGrcryList.Items.Remove(lstGrcryList.SelectedItem)
            lblNumItem.Text = lstGrcryList.Items.Count

        End If

    End Sub

    Private Sub btnClearLst_Click(sender As Object, e As EventArgs) Handles btnClearLst.Click
        lstGrcryList.Items.Clear()
        lblSubTotal.Text = ""
        lblTaxes.Text = ""
        lblFinTotal.Text = ""
        lblNumItem.Text = ""

        dblGroceryListItems = 0.0

    End Sub

    Private Sub btnCountItem_Click(sender As Object, e As EventArgs) Handles btnCountItem.Click
        lblNumItem.Text = lstGrcryList.Items.Count
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
